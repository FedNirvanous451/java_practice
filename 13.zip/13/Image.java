interface Image {
    void display();
}